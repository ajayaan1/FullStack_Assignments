const taskForm = document.getElementById("taskForm");
const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");


taskForm.addEventListener("submit", function (e) {
  e.preventDefault();
  const taskText = taskInput.value.trim();
  if (taskText === "") return;

  addTask(taskText);
  taskInput.value = "";
});


function addTask(taskText) {
  const li = document.createElement("li");
  li.className = "list-group-item d-flex justify-content-between align-items-center";

  li.innerHTML = `
    <span class="task-text">${taskText}</span>
    <div>
      <button class="btn btn-sm btn-warning me-2 edit-btn">Edit</button>
      <button class="btn btn-sm btn-danger delete-btn">Delete</button>
      <button class="btn btn-sm btn-success complete-btn">✔</button>
    </div>
  `;

  taskList.appendChild(li);
}


taskList.addEventListener("click", function (e) {
  const li = e.target.closest("li");

  if (e.target.classList.contains("delete-btn")) {
    li.remove();
  } 
  else if (e.target.classList.contains("edit-btn")) {
    const span = li.querySelector(".task-text");
    const newText = prompt("Edit your task:", span.textContent);
    if (newText !== null && newText.trim() !== "") {
      span.textContent = newText.trim();
    }
  }
  else if (e.target.classList.contains("complete-btn")) {
    const span = li.querySelector(".task-text");
    span.classList.toggle("completed");
    li.classList.toggle("list-group-item-success");
  }
});
