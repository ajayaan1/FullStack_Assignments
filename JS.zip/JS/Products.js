export const products = [
    {
      id: 1,
      name: 'Wireless Headphones',
      price: 99,
      category: 'Electronics',
      rating: 4.5,
      image: 'https://via.placeholder.com/150',
    },
    {
      id: 2,
      name: 'Running Shoes',
      price: 120,
      category: 'Fashion',
      rating: 4.2,
      image: 'https://via.placeholder.com/150',
    },
    {
      id: 3,
      name: 'Smart Watch',
      price: 250,
      category: 'Electronics',
      rating: 4.7,
      image: 'https://via.placeholder.com/150',
    },
    {
      id: 4,
      name: 'Leather Wallet',
      price: 60,
      category: 'Accessories',
      rating: 4.0,
      image: 'https://via.placeholder.com/150',
    },
    {
      id: 5,
      name: 'Sports Jacket',
      price: 180,
      category: 'Fashion',
      rating: 4.3,
      image: 'https://via.placeholder.com/150',
    },
  ];
  