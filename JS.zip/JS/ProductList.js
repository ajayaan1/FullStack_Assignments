import React from 'react';
import ProductCard from './ProductCard';

const ProductList = ({ filteredProducts }) => {
  if (filteredProducts.length === 0) {
    return <p className="text-center text-muted">No products found.</p>;
  }

  return (
    <div className="row g-4">
      {filteredProducts.map((product) => (
        <div className="col-md-4 col-lg-3" key={product.id}>
          <ProductCard product={product} />
        </div>
      ))}
    </div>
  );
};

export default ProductList;
