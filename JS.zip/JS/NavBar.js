import React from 'react';

const Navbar = () => {
  return (
    <nav className="navbar bg-primary text-white p-3">
      <h2 className="m-0">🛍️ Product List</h2>
    </nav>
  );
};

export default Navbar;
