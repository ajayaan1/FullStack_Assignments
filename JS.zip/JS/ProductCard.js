import React from 'react';

const ProductCard = ({ product }) => {
  const handleAddToCart = () => {
    console.log(`Added to cart: ${product.name}`);
    alert(`${product.name} added to cart!`);
  };

  return (
    <div className="card p-2 shadow-sm">
      <img src={product.image} className="card-img-top" alt={product.name} />
      <div className="card-body">
        <h5>{product.name}</h5>
        <p>Category: {product.category}</p>
        <p>💰 ${product.price}</p>
        <p>⭐ {product.rating}</p>
        <button className="btn btn-primary w-100" onClick={handleAddToCart}>
          Add to Cart
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
