import React from 'react';

const FilterBar = ({ category, setCategory, sort, setSort }) => {
  return (
    <div className="d-flex gap-3 mb-3">
      <select
        className="form-select w-auto"
        value={category}
        onChange={(e) => setCategory(e.target.value)}
      >
        <option value="">All Categories</option>
        <option value="Electronics">Electronics</option>
        <option value="Fashion">Fashion</option>
        <option value="Accessories">Accessories</option>
      </select>

      <select
        className="form-select w-auto"
        value={sort}
        onChange={(e) => setSort(e.target.value)}
      >
        <option value="">Sort By</option>
        <option value="priceLow">Price: Low to High</option>
        <option value="priceHigh">Price: High to Low</option>
        <option value="rating">Rating</option>
      </select>
    </div>
  );
};

export default FilterBar;
