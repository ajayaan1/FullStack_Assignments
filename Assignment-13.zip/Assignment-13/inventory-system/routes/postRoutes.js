// routes/postRoutes.js
const express = require('express');
const router = express.Router();
const Post = require('../models/post');

// 🟢 GET all posts
// Route: GET /getPosts
router.get('/getPosts', async (req, res) => {
  try {
    const posts = await Post.find();
    res.status(200).json(posts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🟡 POST a new post
// Route: POST /addPosts
router.post('/addPosts', async (req, res) => {
  try {
    const { title, content } = req.body;
    const newPost = new Post({ title, content });
    await newPost.save();
    res.status(201).json(newPost);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// 🔴 DELETE a post
// Route: DELETE /delPosts/:id
router.delete('/delPosts/:id', async (req, res) => {
  try {
    const deleted = await Post.findByIdAndDelete(req.params.id);
    if (!deleted) return res.status(404).json({ message: 'Post not found' });
    res.json({ message: '✅ Post deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 🟠 PATCH update a post
// Route: PATCH /post/:id
router.patch('/post/:id', async (req, res) => {
  try {
    const updated = await Post.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { new: true }
    );
    if (!updated) return res.status(404).json({ message: 'Post not found' });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

module.exports = router;
