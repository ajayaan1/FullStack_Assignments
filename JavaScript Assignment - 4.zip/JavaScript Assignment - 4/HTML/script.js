const apiUrl = "http://localhost:3000/contacts";
let editId = null;


async function fetchContacts() {
  const res = await fetch(apiUrl);
  const data = await res.json();
  displayContacts(data);
}


function displayContacts(contacts) {
  const tbody = document.querySelector("#contactTable tbody");
  tbody.innerHTML = "";
  contacts.forEach(contact => {
    tbody.innerHTML += `
      <tr>
        <td>${contact.id}</td>
        <td>${contact.name}</td>
        <td>${contact.phone}</td>
        <td>${contact.email}</td>
        <td>
          <button onclick="editContact(${contact.id})">Edit</button>
          <button onclick="deleteContact(${contact.id})">Delete</button>
        </td>
      </tr>
    `;
  });
}

// Add new contact
document.getElementById("addBtn").addEventListener("click", async () => {
  const name = document.getElementById("name").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const email = document.getElementById("email").value.trim();

  if (!name || !phone || !email) {
    alert("Please fill all fields!");
    return;
  }

  await fetch(apiUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, phone, email })
  });

  clearForm();
  fetchContacts();
});


async function editContact(id) {
  const res = await fetch(`${apiUrl}/${id}`);
  const contact = await res.json();

  document.getElementById("name").value = contact.name;
  document.getElementById("phone").value = contact.phone;
  document.getElementById("email").value = contact.email;

  editId = id;
  document.getElementById("addBtn").style.display = "none";
  document.getElementById("updateBtn").style.display = "inline";
}


document.getElementById("updateBtn").addEventListener("click", async () => {
  const name = document.getElementById("name").value.trim();
  const phone = document.getElementById("phone").value.trim();
  const email = document.getElementById("email").value.trim();

  await fetch(`${apiUrl}/${editId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, phone, email })
  });

  clearForm();
  fetchContacts();
  document.getElementById("addBtn").style.display = "inline";
  document.getElementById("updateBtn").style.display = "none";
});


async function deleteContact(id) {
  if (confirm("Are you sure you want to delete this contact?")) {
    await fetch(`${apiUrl}/${id}`, { method: "DELETE" });
    fetchContacts();
  }
}


document.getElementById("search").addEventListener("input", async (e) => {
  const query = e.target.value.toLowerCase();
  const res = await fetch(apiUrl);
  const data = await res.json();
  const filtered = data.filter(
    c => c.name.toLowerCase().includes(query) || c.phone.includes(query)
  );
  displayContacts(filtered);
});


function clearForm() {
  document.getElementById("name").value = "";
  document.getElementById("phone").value = "";
  document.getElementById("email").value = "";
}


fetchContacts();
