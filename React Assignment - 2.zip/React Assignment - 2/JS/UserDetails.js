import React from 'react';
import { useParams, Link } from 'react-router-dom';

const users = [
  { id: 1, name: "Alice", email: "alice@mail.com" },
  { id: 2, name: "Bob", email: "bob@mail.com" },
  { id: 3, name: "Charlie", email: "charlie@mail.com" },
];

function UserDetail() {
  const { id } = useParams();
  const user = users.find((u) => u.id === parseInt(id));

  if (!user) {
    return <p>User not found!</p>;
  }

  return (
    <div className="container mt-4">
      <h2>👤 User Details</h2>
      <p><strong>Name:</strong> {user.name}</p>
      <p><strong>Email:</strong> {user.email}</p>
      <Link to="/users">🔙 Back to Users</Link>
    </div>
  );
}

export default UserDetail;
