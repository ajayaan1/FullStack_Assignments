import React from 'react';

function About() {
  return (
    <div className="container mt-4">
      <h2>ℹ️ About Page</h2>
      <p>This project demonstrates basic routing in React using react-router-dom.</p>
    </div>
  );
}

export default About;
