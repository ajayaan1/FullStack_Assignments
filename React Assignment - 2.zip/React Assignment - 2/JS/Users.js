import React from 'react';
import { Link } from 'react-router-dom';

const users = [
  { id: 1, name: "Alice", email: "alice@mail.com" },
  { id: 2, name: "Bob", email: "bob@mail.com" },
  { id: 3, name: "Charlie", email: "charlie@mail.com" },
];

function Users() {
  return (
    <div className="container mt-4">
      <h2>👥 Users List</h2>
      <ul>
        {users.map((user) => (
          <li key={user.id}>
            <Link to={`/users/${user.id}`}>{user.name}</Link> — {user.email}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Users;
