import React from 'react';

function Home() {
  return (
    <div className="container mt-4">
      <h2>🏠 Home Page</h2>
      <p>Welcome to the React Routing Demo App!</p>
    </div>
  );
}

export default Home;
