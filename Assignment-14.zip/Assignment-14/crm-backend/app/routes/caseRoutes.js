const express = require("express");
const { getCases, addCase } = require("../controllers/caseController");
const router = express.Router();

router.get("/", getCases);
router.post("/", addCase);

module.exports = router;
