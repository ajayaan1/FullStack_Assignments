const Case = require("../models/Case");

exports.getCases = async (req, res) => {
  try {
    const cases = await Case.find().populate("customer_id");
    res.json(cases);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.addCase = async (req, res) => {
  try {
    const newCase = new Case(req.body);
    const saved = await newCase.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};
