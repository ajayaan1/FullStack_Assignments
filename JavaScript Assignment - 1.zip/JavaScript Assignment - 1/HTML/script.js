
function getGrade(mark) {
    if (mark >= 80) return { gradePoint: 5.0, letter: 'A+' };
    if (mark >= 70) return { gradePoint: 4.0, letter: 'A' };
    if (mark >= 60) return { gradePoint: 3.5, letter: 'A-' };
    if (mark >= 50) return { gradePoint: 3.0, letter: 'B' };
    if (mark >= 40) return { gradePoint: 2.0, letter: 'C' };
    if (mark >= 33) return { gradePoint: 1.0, letter: 'D' };
    return { gradePoint: 0.0, letter: 'F' };
  }
  
 
  function getFinalGrade(gpa) {
    if (gpa === 5.0) return 'A+';
    if (gpa >= 4.0) return 'A';
    if (gpa >= 3.5) return 'A-';
    if (gpa >= 3.0) return 'B';
    if (gpa >= 2.0) return 'C';
    if (gpa >= 1.0) return 'D';
    return 'F';
  }
  

  document.querySelector(".result").addEventListener("reset", function () {
    document.querySelector(".resultTable").innerHTML = "";
    document.querySelector(".overAllResult").innerHTML = "";
  });
  

  document.querySelector(".result").addEventListener("submit", function (e) {
    e.preventDefault();
  
    const subjects = [
      { code: 101, key: "English", name: "English" },
      { code: 107, key: "Mathematics", name: "Mathematics" },
      { code: 109, key: "Chemistry", name: "Chemistry" },
      { code: 111, key: "Physics", name: "Physics" },
      { code: 154, key: "Biology", name: "Biology" },
      
    ];
    
    const studentName = document.getElementById("studentName").value.trim();
    const studentReg = document.getElementById("studentReg").value.trim();
    
    if (!studentName || !studentReg) {
        alert("Please enter both student name and registration number!");
        return;
      }

    let isFail = false;
    let totalGradePoint = 0;
    let subjectCount = 0;
    let optionalPoint = 0;
    let totalMarks = 0;
    let tableRows = "";
  
  
    
    for (const sub of subjects) {
       
      const input = document.querySelector(`.${sub.key}`);
      const mark = parseFloat(input?.value) || 0;
      
  
   

      if (mark > 100) {
        alert(`${sub.name} cannot be more than 100.`);
        input.focus();
        return;
      }
      
      const { gradePoint, letter } = getGrade(mark);
      totalMarks += mark;
  
      const isFailedSubject = mark < 33 && !sub.optional;
      if (isFailedSubject) {
        isFail = true;
      }
  
      if (sub.optional) {
        optionalPoint = Math.max(0, gradePoint - 2);
      } else {
        totalGradePoint += gradePoint;
        subjectCount++;
      }
  
      tableRows += `
        <tr class="${sub.optional ? 'optional-subject' : ''} ${isFailedSubject ? 'fail-row' : ''}">
          <td>${sub.code}</td>
          <td>${sub.name}</td>
          <td>${mark}</td>
          <td>${gradePoint.toFixed(2)}</td>
          <td>${letter}</td>
        </tr>
      `;
    }
  
    const gpa = isFail ? 0 : ((totalGradePoint + optionalPoint) / subjectCount);
    const finalGrade = getFinalGrade(gpa);
    const resultStatus = isFail ? "Fail" : "Pass";
    const statusClass = isFail ? "text-danger" : "text-success";
  
    const resultHTML = `
      <div class="table-container">
        <table class="modern-table">
          <thead>
            <tr>
              <th>Subject Code</th>
              <th>Subject Name</th>
              <th>Marks</th>
              <th>Grade Point</th>
              <th>Letter Grade</th>
            </tr>
          </thead>
          <tbody id="marks">
            ${tableRows}
          </tbody>
        </table>
      </div>
    `;
  
    const overallHTML = `
      <div class="table-container">
        <table class="modern-table mt-4 text-center table-bordered">
          <thead>
            <tr>
              <th>Reg.No</th>
              <th>Name</th>
              <th>Total Marks</th>
              <th>Total Points</th>
              <th>GPA/Point</th>
              <th>Grade</th>
              <th>Result Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="fw-bold">${studentReg}</td>
              <td class="fw-bold">${studentName}</td>
              <td class="fw-bold">${totalMarks}</td>
              <td class="fw-bold">${(totalGradePoint + optionalPoint).toFixed(2)}</td>
              <td class="fw-bold">${gpa.toFixed(2)}</td>
              <td class="fw-bold">${finalGrade}</td>
              <td class="fw-bold ${statusClass}">${resultStatus}</td>
            </tr>
          </tbody>
        </table>
      </div>
    `;
  
    document.querySelector(".resultTable").innerHTML = resultHTML;
    document.querySelector(".overAllResult").innerHTML = overallHTML;
  });
  