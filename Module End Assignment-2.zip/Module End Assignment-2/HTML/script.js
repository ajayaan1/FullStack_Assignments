document.getElementById("signupForm").addEventListener("submit", function (event) {
    event.preventDefault();
  
    const fullname = document.getElementById("fullname");
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const confirmPassword = document.getElementById("confirmPassword");
    const terms = document.getElementById("terms");
  
    let isValid = true;
  
    if (fullname.value.trim() === "") {
      fullname.classList.add("is-invalid");
      isValid = false;
    } else {
      fullname.classList.remove("is-invalid");
    }
  
  
    const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
    if (!emailPattern.test(email.value)) {
      email.classList.add("is-invalid");
      isValid = false;
    } else {
      email.classList.remove("is-invalid");
    }
  
   
    if (password.value.length < 6) {
      password.classList.add("is-invalid");
      isValid = false;
    } else {
      password.classList.remove("is-invalid");
    }
  
 
    if (confirmPassword.value !== password.value || confirmPassword.value === "") {
      confirmPassword.classList.add("is-invalid");
      isValid = false;
    } else {
      confirmPassword.classList.remove("is-invalid");
    }
  
    
    if (!terms.checked) {
      terms.classList.add("is-invalid");
      isValid = false;
    } else {
      terms.classList.remove("is-invalid");
    }
  
    
    if (isValid) {
      alert(`✅ Registration Successful!\nWelcome, ${fullname.value}!`);
      document.getElementById("signupForm").reset();
    }
  });
  