const express = require("express");
const {
  getCustomers,
  addCustomer,
  updateCustomer,
  deleteCustomer
} = require("../controllers/customerController");

const router = express.Router();

// Get all customers
router.get("/", getCustomers);

// Add a new customer
router.post("/", addCustomer);

// ✅ Update a customer by ID
router.patch("/:id", updateCustomer);

// ✅ Delete a customer by ID
router.delete("/:id", deleteCustomer);

module.exports = router;
